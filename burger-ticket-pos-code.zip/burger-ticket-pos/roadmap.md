# Payment and invoice
- [x] Add counter Cash/Mada/Card checkout with cash change.
- [x] Build clear bilingual receipt with photo logo, order barcode and tax QR.
- [x] Connect invoice preview and printing; verify payment and receipt flows.