import type { PosSettings } from "./pos-settings";
import type { PaymentMethod } from "./payment";

export interface ReceiptLine { qty: number; name: string; nameAr?: string; price: number }
export interface ReceiptData {
  checkNo: number;
  orderType: string;
  lines: ReceiptLine[];
  subtotal: number;
  discount: number;
  taxes: number;
  total: number;
  date: Date;
  payment?: { method: PaymentMethod; tendered: number; change: number };
}

function baseUrl(protocol: string, ip: string, port: number) {
  const defPort = protocol === "https" ? 443 : 80;
  return `${protocol}://${ip}${port && port !== defPort ? `:${port}` : ""}`;
}

/** "Ping" the printer: try to reach its web server from this device. */
export async function pingPrinter(s: PosSettings, ip = s.printerIp): Promise<{ ok: boolean; ms: number; error?: string }> {
  const start = performance.now();
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 4000);
  try {
    await fetch(baseUrl(s.printerProtocol, ip, s.printerPort) + "/", { mode: "no-cors", signal: ctrl.signal, cache: "no-store" });
    return { ok: true, ms: Math.round(performance.now() - start) };
  } catch (e) {
    const aborted = (e as Error).name === "AbortError";
    return { ok: false, ms: Math.round(performance.now() - start), error: aborted ? "No reply (timeout)" : "Blocked or unreachable" };
  } finally {
    clearTimeout(t);
  }
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function pad(left: string, right: string, width: number) {
  const space = Math.max(1, width - left.length - right.length);
  return left + " ".repeat(space) + right;
}

export function buildEposXml(s: PosSettings, r: ReceiptData, kitchen = false) {
  const w = s.paperWidth === 58 ? 32 : 48;
  const out: string[] = [];
  out.push(`<text align="center"/><text dw="true" dh="true">${esc(kitchen ? "KITCHEN" : s.storeName)}&#10;</text><text dw="false" dh="false"/>`);
  if (!kitchen) {
    if (s.branchName) out.push(`<text>${esc(s.branchName)}&#10;</text>`);
    if (s.address) out.push(`<text>${esc(s.address)}&#10;</text>`);
    if (s.phone) out.push(`<text>Tel: ${esc(s.phone)}&#10;</text>`);
    if (s.vatNumber) out.push(`<text>VAT No: ${esc(s.vatNumber)}&#10;</text>`);
  }
  out.push(`<text align="left"/><text>${esc(pad(`Check #${r.checkNo}`, r.orderType, w))}&#10;${esc(r.date.toLocaleString())}&#10;${"-".repeat(w)}&#10;</text>`);
  for (const l of r.lines) {
    out.push(`<text>${esc(kitchen ? `${l.qty} x ${l.name}` : pad(`${l.qty} x ${l.name}`, (l.qty * l.price).toFixed(2), w))}&#10;</text>`);
  }
  if (!kitchen) {
    out.push(`<text>${"-".repeat(w)}&#10;${esc(pad("Subtotal", r.subtotal.toFixed(2), w))}&#10;${esc(pad("Discount", r.discount.toFixed(2), w))}&#10;${esc(pad(`VAT ${s.taxRate}% (incl.)`, r.taxes.toFixed(2), w))}&#10;</text>`);
    out.push(`<text dw="true">${esc(pad("TOTAL", "SAR " + r.total.toFixed(2), w / 2))}&#10;</text><text dw="false"/>`);
    if (r.payment) out.push(`<text>${esc(pad(`Payment - ${r.payment.method}`, r.total.toFixed(2), w))}&#10;${esc(pad("Received", r.payment.tendered.toFixed(2), w))}&#10;${esc(pad("Change", r.payment.change.toFixed(2), w))}&#10;</text>`);
    out.push(`<text align="center"/><text>&#10;${esc(s.receiptFooter)}&#10;</text>`);
  }
  out.push(`<feed line="3"/>`);
  if (s.cutPaper) out.push(`<cut type="feed"/>`);
  if (s.openCashDrawer && !kitchen) out.push(`<pulse drawer="drawer_1" time="pulse_100"/>`);
  return `<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print">${out.join("")}</epos-print></s:Body></s:Envelope>`;
}

/** Send to a network printer that supports Epson ePOS-Print (TM series, many clones). */
export async function printNetwork(s: PosSettings, r: ReceiptData, ip = s.printerIp, kitchen = false) {
  const url = `${baseUrl(s.printerProtocol, ip, s.printerPort)}/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000`;
  const body = buildEposXml(s, r, kitchen);
  for (let i = 0; i < (kitchen ? 1 : s.copies); i++) {
    await fetch(url, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/xml; charset=utf-8", SOAPAction: '""' },
      body,
    });
  }
}
