import { useEffect, useState } from "react";

export type PrintMethod = "browser" | "network";

export interface PosSettings {
  storeName: string;
  branchName: string;
  vatNumber: string;
  phone: string;
  address: string;
  cashierName: string;
  taxRate: number; // percent, prices include VAT
  receiptFooter: string;
  printMethod: PrintMethod;
  printerIp: string;
  printerPort: number;
  printerProtocol: "http" | "https";
  paperWidth: 58 | 80;
  copies: number;
  autoPrint: boolean;
  printKitchenTicket: boolean;
  kitchenPrinterIp: string;
  openCashDrawer: boolean;
  cutPaper: boolean;
}

export const defaultSettings: PosSettings = {
  storeName: "Burger Ticket",
  branchName: "Main Branch",
  vatNumber: "",
  phone: "",
  address: "",
  cashierName: "Cashier",
  taxRate: 15,
  receiptFooter: "Thank you! Visit again",
  printMethod: "browser",
  printerIp: "192.168.1.100",
  printerPort: 80,
  printerProtocol: "http",
  paperWidth: 80,
  copies: 1,
  autoPrint: false,
  printKitchenTicket: false,
  kitchenPrinterIp: "",
  openCashDrawer: false,
  cutPaper: true,
};

const KEY = "pos-settings-v1";

export function loadSettings(): PosSettings {
  if (typeof window === "undefined") return defaultSettings;
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? { ...defaultSettings, ...JSON.parse(raw) } : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(s: PosSettings) {
  localStorage.setItem(KEY, JSON.stringify(s));
}

export function useSettings() {
  const [settings, setSettings] = useState<PosSettings>(defaultSettings);
  useEffect(() => setSettings(loadSettings()), []);
  return [settings, setSettings] as const;
}

/** VAT-inclusive breakdown: total already contains tax. */
export function computeTotals(subtotal: number, discount: number, taxRate: number) {
  const total = Math.max(0, subtotal - discount);
  const taxes = total - total / (1 + taxRate / 100);
  return { subtotal, discount, taxes, total };
}
