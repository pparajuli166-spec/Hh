import { toCanvas } from "html-to-image";
import type { PosSettings } from "./pos-settings";

export function packMonochrome(data: Uint8ClampedArray, width: number, height: number) {
  const stride = Math.ceil(width / 8);
  const bytes = new Uint8Array(stride * height);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const index = (y * width + x) * 4;
    const luminance = (data[index] ?? 255) * 0.299 + (data[index + 1] ?? 255) * 0.587 + (data[index + 2] ?? 255) * 0.114;
    const target = y * stride + Math.floor(x / 8);
    if ((data[index + 3] ?? 0) > 127 && luminance < 160) bytes[target] = (bytes[target] ?? 0) | (128 >> (x % 8));
  }
  return bytes;
}

export async function waitForInvoice(element: HTMLElement) {
  await document.fonts.ready;
  await Promise.all(Array.from(element.querySelectorAll("img")).map(async img => {
    await img.decode();
    if (!img.naturalWidth) throw new Error("Invoice logo did not load");
  }));
  await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
}

export async function printInvoiceNetwork(element: HTMLElement, s: PosSettings) {
  await waitForInvoice(element);
  const width = s.paperWidth === 58 ? 384 : 576;
  const canvas = await toCanvas(element, { pixelRatio: width / element.getBoundingClientRect().width, cacheBust: false });
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not render invoice");
  const bytes = packMonochrome(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  const body = `<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print"><image width="${canvas.width}" height="${canvas.height}" color="color_1" mode="mono">${btoa(binary)}</image><feed line="3"/>${s.cutPaper ? '<cut type="feed"/>' : ""}${s.openCashDrawer ? '<pulse drawer="drawer_1" time="pulse_100"/>' : ""}</epos-print></s:Body></s:Envelope>`;
  const port = s.printerPort === (s.printerProtocol === "https" ? 443 : 80) ? "" : `:${s.printerPort}`;
  for (let i = 0; i < s.copies; i++) {
    const response = await fetch(`${s.printerProtocol}://${s.printerIp}${port}/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000`, { method: "POST", headers: { "Content-Type": "text/xml; charset=utf-8" }, body, signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error(`Printer replied ${response.status}`);
    const result = new DOMParser().parseFromString(await response.text(), "text/xml").getElementsByTagName("response")[0];
    if (result?.getAttribute("success") !== "true") throw new Error(result?.getAttribute("code") || "Printer did not confirm printing");
  }
}