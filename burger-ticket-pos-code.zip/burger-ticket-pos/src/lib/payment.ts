export type PaymentMethod = "Cash" | "Mada" | "Card";
export const paymentMethods: PaymentMethod[] = ["Cash", "Mada", "Card"];
export function settlePayment(total: number, method: PaymentMethod, tendered: number) {
  const due = Math.round(total * 100);
  if (!Number.isFinite(total) || due <= 0) throw new Error("Add items first");
  if (!paymentMethods.includes(method)) throw new Error("Select a payment method");
  const received = method === "Cash" ? Math.round(tendered * 100) : due;
  if (!Number.isFinite(received) || received < due) throw new Error("Cash received is less than the total");
  return { method, tendered: received / 100, change: (received - due) / 100 };
}

/** Phase 1 TLV only; this is not a Phase 2 signed e-invoice. */
export function taxQrPayload(seller: string, vat: string, date: Date, total: number, tax: number) {
  if (!seller.trim() || !/^\d{15}$/.test(vat)) return null;
  const values = [seller, vat, date.toISOString(), total.toFixed(2), tax.toFixed(2)];
  const bytes: number[] = [];
  values.forEach((value, i) => {
    const encoded = new TextEncoder().encode(value);
    if (encoded.length > 255) throw new Error("Seller name is too long for the tax QR");
    bytes.push(i + 1, encoded.length, ...encoded);
  });
  return btoa(String.fromCharCode(...bytes));
}