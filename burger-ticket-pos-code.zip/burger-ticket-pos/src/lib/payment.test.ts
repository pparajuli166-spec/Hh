import { describe, expect, it } from "vitest";
import { paymentMethods, settlePayment, taxQrPayload } from "./payment";

describe("Counter payments", () => {
  it("offers Cash, Mada and Card only", () => expect(paymentMethods).toEqual(["Cash", "Mada", "Card"]));
  it("calculates cash change in halalas", () => expect(settlePayment(44, "Cash", 50)).toEqual({ method: "Cash", tendered: 50, change: 6 }));
  it("rejects insufficient cash", () => expect(() => settlePayment(44, "Cash", 43)).toThrow());
  it("Mada records exact total without change", () => expect(settlePayment(44, "Mada", 0)).toEqual({ method: "Mada", tendered: 44, change: 0 }));
  it("Card records exact total without change", () => expect(settlePayment(44, "Card", 100)).toEqual({ method: "Card", tendered: 44, change: 0 }));
  it("rejects empty orders", () => expect(() => settlePayment(0, "Cash", 50)).toThrow());
  it("does not invent tax credentials", () => expect(taxQrPayload("Burger Ticket", "", new Date(), 44, 5.74)).toBeNull());
  it("encodes total and VAT in TLV tags 4 and 5", () => {
    const payload = taxQrPayload("Restaurant", "310364988600003", new Date("2026-11-09T01:02:55Z"), 44, 5.74);
    if (!payload) throw new Error("Missing QR");
    const bytes = Uint8Array.from(atob(payload), c => c.charCodeAt(0));
    const fields: Record<number, string> = {};
    for (let i = 0; i < bytes.length;) { const tag = bytes[i++]; const length = bytes[i++]; if (tag === undefined || length === undefined) throw new Error("Malformed TLV"); fields[tag] = new TextDecoder().decode(bytes.slice(i, i + length)); i += length; }
    expect(fields[4]).toBe("44.00"); expect(fields[5]).toBe("5.74"); expect(fields[3]).toBe("2026-11-09T01:02:55.000Z");
  });
});