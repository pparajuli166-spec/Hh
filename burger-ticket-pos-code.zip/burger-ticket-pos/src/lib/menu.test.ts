import { describe, expect, it } from "vitest";
import { categories } from "./menu";

describe("Original Burger Ticket menu", () => {
  it("contains the six original categories and 45 items", () => {
    expect(categories.map(c => c.name)).toEqual(["Meals", "Burgers", "Sandwiches", "Combos", "Sides", "Drinks"]);
    expect(categories.flatMap(c => c.products)).toHaveLength(45);
  });
  it("preserves Chicken Broast at 19.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Chicken Broast")?.price).toBe(19.0);
  });
  it("preserves Chicken Fillet at 20.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Chicken Fillet")?.price).toBe(20.0);
  });
  it("preserves Nuggets 7 Pcs at 15.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Nuggets 7 Pcs")?.price).toBe(15.0);
  });
  it("preserves Nuggets 10 Pcs at 18.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Nuggets 10 Pcs")?.price).toBe(18.0);
  });
  it("preserves Shrimp at 22.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Shrimp")?.price).toBe(22.0);
  });
  it("preserves Shrimp Jambo at 32.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Shrimp Jambo")?.price).toBe(32.0);
  });
  it("preserves Fish Fillet at 18.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Fish Fillet")?.price).toBe(18.0);
  });
  it("preserves Shawarma Box at 13.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Shawarma Box")?.price).toBe(13.0);
  });
  it("preserves Super Chicken Meal at 17.0", () => {
    expect(categories.find(c => c.id === "meals")?.products.find(p => p.name === "Super Chicken Meal")?.price).toBe(17.0);
  });
  it("preserves Chicken Fillet Burger at 5.5", () => {
    expect(categories.find(c => c.id === "burgers")?.products.find(p => p.name === "Chicken Fillet Burger")?.price).toBe(5.5);
  });
  it("preserves Double Burger at 9.0", () => {
    expect(categories.find(c => c.id === "burgers")?.products.find(p => p.name === "Double Burger")?.price).toBe(9.0);
  });
  it("preserves Zinger Burger at 11.0", () => {
    expect(categories.find(c => c.id === "burgers")?.products.find(p => p.name === "Zinger Burger")?.price).toBe(11.0);
  });
  it("preserves Super Chicken Sandwich at 12.0", () => {
    expect(categories.find(c => c.id === "sandwiches")?.products.find(p => p.name === "Super Chicken Sandwich")?.price).toBe(12.0);
  });
  it("preserves Big Fillet at 14.0", () => {
    expect(categories.find(c => c.id === "sandwiches")?.products.find(p => p.name === "Big Fillet")?.price).toBe(14.0);
  });
  it("preserves Crunchi Sandwich Cheese at 6.0", () => {
    expect(categories.find(c => c.id === "sandwiches")?.products.find(p => p.name === "Crunchi Sandwich Cheese")?.price).toBe(6.0);
  });
  it("preserves Shawarma at 6.0", () => {
    expect(categories.find(c => c.id === "sandwiches")?.products.find(p => p.name === "Shawarma")?.price).toBe(6.0);
  });
  it("preserves Chicken Fillet Sandwich at 7.0", () => {
    expect(categories.find(c => c.id === "sandwiches")?.products.find(p => p.name === "Chicken Fillet Sandwich")?.price).toBe(7.0);
  });
  it("preserves Sharing Combo at 60.0", () => {
    expect(categories.find(c => c.id === "combos")?.products.find(p => p.name === "Sharing Combo")?.price).toBe(60.0);
  });
  it("preserves Kids Meal at 13.0", () => {
    expect(categories.find(c => c.id === "combos")?.products.find(p => p.name === "Kids Meal")?.price).toBe(13.0);
  });
  it("preserves Hommos at 5.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Hommos")?.price).toBe(5.0);
  });
  it("preserves Coleslaw Salad at 4.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Coleslaw Salad")?.price).toBe(4.0);
  });
  it("preserves Onion Rings at 7.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Onion Rings")?.price).toBe(7.0);
  });
  it("preserves French Fries at 6.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "French Fries")?.price).toBe(6.0);
  });
  it("preserves Bun at 0.5", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Bun")?.price).toBe(0.5);
  });
  it("preserves Bread at 0.5", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Bread")?.price).toBe(0.5);
  });
  it("preserves Nugget Sauce at 1.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Nugget Sauce")?.price).toBe(1.0);
  });
  it("preserves Cocktail Sauce at 1.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Cocktail Sauce")?.price).toBe(1.0);
  });
  it("preserves Garlic Sauce Small at 0.75", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Garlic Sauce Small")?.price).toBe(0.75);
  });
  it("preserves Garlic Sauce Big at 4.0", () => {
    expect(categories.find(c => c.id === "sides")?.products.find(p => p.name === "Garlic Sauce Big")?.price).toBe(4.0);
  });
  it("preserves Pepsi at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Pepsi")?.price).toBe(3.0);
  });
  it("preserves Diet Pepsi at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Diet Pepsi")?.price).toBe(3.0);
  });
  it("preserves 7UP at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "7UP")?.price).toBe(3.0);
  });
  it("preserves Diet 7UP at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Diet 7UP")?.price).toBe(3.0);
  });
  it("preserves Mirinda Citrus at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mirinda Citrus")?.price).toBe(3.0);
  });
  it("preserves Mirinda Orange at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mirinda Orange")?.price).toBe(3.0);
  });
  it("preserves Orange Juice Small at 2.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Orange Juice Small")?.price).toBe(2.0);
  });
  it("preserves Orange Juice Large at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Orange Juice Large")?.price).toBe(3.0);
  });
  it("preserves Mixed Fruit Juice Small at 2.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mixed Fruit Juice Small")?.price).toBe(2.0);
  });
  it("preserves Mixed Fruit Juice Large at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mixed Fruit Juice Large")?.price).toBe(3.0);
  });
  it("preserves Apple Juice Small at 2.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Apple Juice Small")?.price).toBe(2.0);
  });
  it("preserves Apple Juice Large at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Apple Juice Large")?.price).toBe(3.0);
  });
  it("preserves Mango Juice Small at 2.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mango Juice Small")?.price).toBe(2.0);
  });
  it("preserves Mango Juice Large at 3.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Mango Juice Large")?.price).toBe(3.0);
  });
  it("preserves Water Small at 0.5", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Water Small")?.price).toBe(0.5);
  });
  it("preserves Water Big at 1.0", () => {
    expect(categories.find(c => c.id === "drinks")?.products.find(p => p.name === "Water Big")?.price).toBe(1.0);
  });
});
