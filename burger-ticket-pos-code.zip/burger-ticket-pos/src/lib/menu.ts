import menuImage0 from "@/assets/original-menu/broast-DEY7AOi1.jpg.asset.json";
import menuImage1 from "@/assets/original-menu/chicken-fillet-D0hi0RC2.jpg.asset.json";
import menuImage2 from "@/assets/original-menu/chicken-sandwich-DceY4ecp.jpg.asset.json";
import menuImage3 from "@/assets/original-menu/coleslaw-Df5THsXD.jpg.asset.json";
import menuImage4 from "@/assets/original-menu/crunchi-cheese-BxF6BamJ.jpg.asset.json";
import menuImage5 from "@/assets/original-menu/double-burger-CyYW3Mvr.jpg.asset.json";
import menuImage6 from "@/assets/original-menu/fillet-burger-CZe-7_51.jpg.asset.json";
import menuImage7 from "@/assets/original-menu/fish-fillet-B1TYi-xr.jpg.asset.json";
import menuImage8 from "@/assets/original-menu/fries-DIfyp4pX.jpg.asset.json";
import menuImage9 from "@/assets/original-menu/hummus-ma4dhAVd.jpg.asset.json";
import menuImage10 from "@/assets/original-menu/juice-BaeR_C0n.jpg.asset.json";
import menuImage11 from "@/assets/original-menu/kids-meal-BDJw2ZAT.jpg.asset.json";
import menuImage12 from "@/assets/original-menu/nuggets-DKew6CM7.jpg.asset.json";
import menuImage13 from "@/assets/original-menu/onion-rings-RJp6btSc.jpg.asset.json";
import menuImage14 from "@/assets/original-menu/sauces-bread-sHwLjE5G.jpg.asset.json";
import menuImage15 from "@/assets/original-menu/sharing-combo-BmEPIARm.jpg.asset.json";
import menuImage16 from "@/assets/original-menu/shawarma-DuKQOTef.jpg.asset.json";
import menuImage17 from "@/assets/original-menu/shawarma-box-D5FVqTIj.jpg.asset.json";
import menuImage18 from "@/assets/original-menu/shrimp-kj2Yl66N.jpg.asset.json";
import menuImage19 from "@/assets/original-menu/soda-lp_x7j9N.jpg.asset.json";
import menuImage20 from "@/assets/original-menu/super-meal-C4UkqnT3.jpg.asset.json";
import menuImage21 from "@/assets/original-menu/water-C8ZF1mi1.jpg.asset.json";
import menuImage22 from "@/assets/original-menu/zinger-burger-5oqvrOLj.jpg.asset.json";

export interface Product { id: string; name: string; nameAr: string; price: number; image: string }
export interface Category { id: string; name: string; image: string; products: Product[] }

// Item names and prices restored from the original published Burger Ticket menu.
export const categories: Category[] = [
  { id: "meals", name: "Meals", image: menuImage0.url, products: [
    { id: "meals-0", name: "Chicken Broast", nameAr: "بروستد دجاج", price: 19.0, image: menuImage0.url },
    { id: "meals-1", name: "Chicken Fillet", nameAr: "فيلية دجاج", price: 20.0, image: menuImage1.url },
    { id: "meals-2", name: "Nuggets 7 Pcs", nameAr: "مسحب دجاج ٧", price: 15.0, image: menuImage12.url },
    { id: "meals-3", name: "Nuggets 10 Pcs", nameAr: "مسحب دجاج ١٠", price: 18.0, image: menuImage12.url },
    { id: "meals-4", name: "Shrimp", nameAr: "جمبري", price: 22.0, image: menuImage18.url },
    { id: "meals-5", name: "Shrimp Jambo", nameAr: "جمبري جامبو", price: 32.0, image: menuImage18.url },
    { id: "meals-6", name: "Fish Fillet", nameAr: "فيلية سمك", price: 18.0, image: menuImage7.url },
    { id: "meals-7", name: "Shawarma Box", nameAr: "بوكس شاورما", price: 13.0, image: menuImage17.url },
    { id: "meals-8", name: "Super Chicken Meal", nameAr: "سوبر دجاج وجبة", price: 17.0, image: menuImage20.url },
  ] },
  { id: "burgers", name: "Burgers", image: menuImage22.url, products: [
    { id: "burgers-0", name: "Chicken Fillet Burger", nameAr: "برجر فيليه", price: 5.5, image: menuImage6.url },
    { id: "burgers-1", name: "Double Burger", nameAr: "دبل برجر", price: 9.0, image: menuImage5.url },
    { id: "burgers-2", name: "Zinger Burger", nameAr: "زنجر برجر", price: 11.0, image: menuImage22.url },
  ] },
  { id: "sandwiches", name: "Sandwiches", image: menuImage2.url, products: [
    { id: "sandwiches-0", name: "Super Chicken Sandwich", nameAr: "سوبر دجاج ساندوتش", price: 12.0, image: menuImage2.url },
    { id: "sandwiches-1", name: "Big Fillet", nameAr: "بيج فيليه", price: 14.0, image: menuImage2.url },
    { id: "sandwiches-2", name: "Crunchi Sandwich Cheese", nameAr: "كرنشي ساندوتش", price: 6.0, image: menuImage4.url },
    { id: "sandwiches-3", name: "Shawarma", nameAr: "شاورما", price: 6.0, image: menuImage16.url },
    { id: "sandwiches-4", name: "Chicken Fillet Sandwich", nameAr: "ساندوتش فيليه", price: 7.0, image: menuImage2.url },
  ] },
  { id: "combos", name: "Combos", image: menuImage15.url, products: [
    { id: "combos-0", name: "Sharing Combo", nameAr: "كومبو المشاركة", price: 60.0, image: menuImage15.url },
    { id: "combos-1", name: "Kids Meal", nameAr: "وجبة أطفال", price: 13.0, image: menuImage11.url },
  ] },
  { id: "sides", name: "Sides", image: menuImage8.url, products: [
    { id: "sides-0", name: "Hommos", nameAr: "حمص", price: 5.0, image: menuImage9.url },
    { id: "sides-1", name: "Coleslaw Salad", nameAr: "سلطة ملفوف", price: 4.0, image: menuImage3.url },
    { id: "sides-2", name: "Onion Rings", nameAr: "حلقات بصل", price: 7.0, image: menuImage13.url },
    { id: "sides-3", name: "French Fries", nameAr: "بطاطس مقلية", price: 6.0, image: menuImage8.url },
    { id: "sides-4", name: "Bun", nameAr: "خبز كعك", price: 0.5, image: menuImage14.url },
    { id: "sides-5", name: "Bread", nameAr: "خبز", price: 0.5, image: menuImage14.url },
    { id: "sides-6", name: "Nugget Sauce", nameAr: "صلصة مسحب", price: 1.0, image: menuImage14.url },
    { id: "sides-7", name: "Cocktail Sauce", nameAr: "صوص كوكتيل", price: 1.0, image: menuImage14.url },
    { id: "sides-8", name: "Garlic Sauce Small", nameAr: "صلصة ثوم صغير", price: 0.75, image: menuImage14.url },
    { id: "sides-9", name: "Garlic Sauce Big", nameAr: "صلصة ثوم كبير", price: 4.0, image: menuImage14.url },
  ] },
  { id: "drinks", name: "Drinks", image: menuImage10.url, products: [
    { id: "drinks-0", name: "Pepsi", nameAr: "بيبسي", price: 3.0, image: menuImage19.url },
    { id: "drinks-1", name: "Diet Pepsi", nameAr: "بيبسي دايت 330م", price: 3.0, image: menuImage19.url },
    { id: "drinks-2", name: "7UP", nameAr: "سفن أب", price: 3.0, image: menuImage19.url },
    { id: "drinks-3", name: "Diet 7UP", nameAr: "سفن أب دايت", price: 3.0, image: menuImage19.url },
    { id: "drinks-4", name: "Mirinda Citrus", nameAr: "ميرندا حمضيات", price: 3.0, image: menuImage19.url },
    { id: "drinks-5", name: "Mirinda Orange", nameAr: "ميرندا برتقال", price: 3.0, image: menuImage19.url },
    { id: "drinks-6", name: "Orange Juice Small", nameAr: "عصير برتقال صغير", price: 2.0, image: menuImage10.url },
    { id: "drinks-7", name: "Orange Juice Large", nameAr: "عصير برتقال كبير", price: 3.0, image: menuImage10.url },
    { id: "drinks-8", name: "Mixed Fruit Juice Small", nameAr: "عصير فواكه مشكلة صغير", price: 2.0, image: menuImage10.url },
    { id: "drinks-9", name: "Mixed Fruit Juice Large", nameAr: "عصير فواكه مشكلة كبير", price: 3.0, image: menuImage10.url },
    { id: "drinks-10", name: "Apple Juice Small", nameAr: "عصير تفاح صغير", price: 2.0, image: menuImage10.url },
    { id: "drinks-11", name: "Apple Juice Large", nameAr: "عصير تفاح كبير", price: 3.0, image: menuImage10.url },
    { id: "drinks-12", name: "Mango Juice Small", nameAr: "عصير مانجو صغير", price: 2.0, image: menuImage10.url },
    { id: "drinks-13", name: "Mango Juice Large", nameAr: "عصير مانجو كبير", price: 3.0, image: menuImage10.url },
    { id: "drinks-14", name: "Water Small", nameAr: "ماء صغير", price: 0.5, image: menuImage21.url },
    { id: "drinks-15", name: "Water Big", nameAr: "ماء كبير", price: 1.0, image: menuImage21.url },
  ] },
];
