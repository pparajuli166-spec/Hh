import { expect, it } from "vitest";
import { packMonochrome } from "./receipt-print";
it("packs black pixels MSB first with separate padded rows", () => {
  const data = new Uint8ClampedArray(9 * 2 * 4).fill(255);
  for (const pixel of [0, 8, 10]) { data[pixel * 4] = 0; data[pixel * 4 + 1] = 0; data[pixel * 4 + 2] = 0; }
  expect(Array.from(packMonochrome(data, 9, 2))).toEqual([128, 128, 64, 0]);
});