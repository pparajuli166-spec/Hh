import { useEffect, useRef } from "react";
import JsBarcode from "jsbarcode";
import { QRCodeSVG } from "qrcode.react";
import logo from "@/assets/restaurant-logo-crop.png.asset.json";
import type { PosSettings } from "@/lib/pos-settings";
import type { ReceiptData } from "@/lib/printer";
import { taxQrPayload } from "@/lib/payment";
import { Money } from "./Riyal";

function OrderBarcode({ number }: { number: number }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    JsBarcode(ref.current, String(number), { format: "CODE128", width: 2, height: 48, margin: 8, displayValue: true, fontSize: 16 });
  }, [number]);
  return <svg ref={ref} className="invoice-barcode" role="img" aria-label={`Order barcode ${number}`} />;
}

export function Invoice({ r, settings: s, id }: { r: ReceiptData; settings: PosSettings; id?: string }) {
  const qr = taxQrPayload(s.storeName, s.vatNumber, r.date, r.total, r.taxes);
  return (
    <article id={id} className={`invoice-paper ${s.paperWidth === 58 ? "invoice-58" : "invoice-80"}`}>
      <header className="invoice-header">
        <img src={logo.url} alt="Restaurant logo" className="invoice-logo" />
        <strong>{s.storeName}</strong>
        {s.branchName && <div>{s.branchName}</div>}
        {s.address && <div>{s.address}</div>}
        {s.phone && <div>Tel: {s.phone}</div>}
        {s.vatNumber && <div>{s.vatNumber}</div>}
        <div>{qr ? "Simplified Tax Invoice" : "Receipt"}</div>
        <div lang="ar" dir="rtl">{qr ? "فاتورة ضريبية مبسطة" : "إيصال"}</div>
        <h2>Order# {r.checkNo}</h2>
      </header>
      <div className="invoice-meta"><span>{r.orderType}</span><span>{r.payment ? "PAID" : "UNPAID"}</span></div>
      <div>Printed: {r.date.toLocaleString("en-GB", { timeZone: "Asia/Riyadh", hour12: true })}</div>
      <div>Creator: {s.cashierName}</div>
      <table className="invoice-table">
        <thead><tr><th>Qty</th><th>Item<br /><span lang="ar">المنتج</span></th><th>Unit Price<br /><span lang="ar">سعر الوحدة</span></th><th>With VAT<br /><span lang="ar">شامل الضريبة</span></th></tr></thead>
        <tbody>{r.lines.map((l, i) => <tr key={i}><td>{l.qty}</td><td>{l.name}{l.nameAr && <div lang="ar" dir="rtl">{l.nameAr}</div>}</td><td>{(l.price / (1 + s.taxRate / 100)).toFixed(2)}</td><td><Money value={l.qty * l.price} /></td></tr>)}</tbody>
      </table>
      {r.discount > 0 && <Summary label="Discount / الخصم" value={r.discount} />}
      <Summary label="Taxable Amount / المبلغ الخاضع للضريبة" value={r.total - r.taxes} />
      <Summary label={`Tax (${s.taxRate}%) / الضريبة`} value={r.taxes} />
      <Summary label="Total including Tax / المجموع" value={r.total} strong />
      {r.payment && <><Summary label={`Payment - ${r.payment.method}`} value={r.total} />{r.payment.method === "Cash" && <><Summary label="Cash received / النقد المستلم" value={r.payment.tendered} /><Summary label="Change / الباقي" value={r.payment.change} /></>}</>}
      <p className="invoice-count">Products Count {r.lines.reduce((sum, l) => sum + l.qty, 0)}</p>
      <footer className="invoice-footer"><p>{s.receiptFooter}</p><p lang="ar" dir="rtl">شكراً لزيارتكم</p><OrderBarcode number={r.checkNo} />{qr && <QRCodeSVG value={qr} size={180} level="M" marginSize={4} className="invoice-qr" title="Tax invoice QR" />}</footer>
    </article>
  );
}
function Summary({ label, value, strong }: { label: string; value: number; strong?: boolean }) {
  return <div className={`invoice-summary ${strong ? "invoice-total" : ""}`}><span>{label}</span><Money value={value} /></div>;
}