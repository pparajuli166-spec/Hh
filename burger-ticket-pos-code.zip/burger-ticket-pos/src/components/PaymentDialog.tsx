import { useState } from "react";
import { Banknote, CreditCard, Check } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Money } from "./Riyal";
import { paymentMethods, settlePayment, type PaymentMethod } from "@/lib/payment";
import type { ReceiptData } from "@/lib/printer";

export function PaymentDialog({ total, onClose, onComplete }: { total: number; onClose: () => void; onComplete: (payment: NonNullable<ReceiptData["payment"]>) => void }) {
  const [method, setMethod] = useState<PaymentMethod>("Cash");
  const [cash, setCash] = useState(total.toFixed(2));
  const [error, setError] = useState("");
  const change = Math.max(0, Math.round((Number(cash) - total) * 100) / 100);
  return <Dialog open onOpenChange={open => { if (!open) onClose(); }}><DialogContent className="max-w-[calc(100vw-1.5rem)] bg-card sm:max-w-md"><DialogTitle>Payment</DialogTitle><DialogDescription>Order total <Money value={total} /></DialogDescription>
    <div className="grid grid-cols-3 gap-2">{paymentMethods.map(m => <Button key={m} variant={m === method ? "default" : "outline"} className="h-16 flex-col" aria-pressed={method === m} onClick={() => { setMethod(m); setError(""); }}>{m === "Cash" ? <Banknote /> : <CreditCard />}{m}</Button>)}</div>
    {method === "Cash" ? <><label className="grid gap-2 font-semibold">Cash received<input autoFocus type="number" min={0} step="0.01" value={cash} onChange={e => setCash(e.target.value)} className="rounded-md border bg-card px-3 py-3 text-xl" /></label><div className="flex justify-between"><span>Change</span><Money value={change} /></div></> : <label className="flex gap-2 text-sm"><input type="checkbox" required id="terminal-confirmation" />Payment approved on the card terminal</label>}
    {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    <Button className="h-12" onClick={() => { try { if (method !== "Cash" && !(document.getElementById("terminal-confirmation") as HTMLInputElement | null)?.checked) { setError("Confirm approval on your card terminal first"); return; } onComplete(settlePayment(total, method, Number(cash))); } catch (e) { setError(e instanceof Error ? e.message : "Check payment"); } }}><Check />Confirm payment</Button>
  </DialogContent></Dialog>;
}