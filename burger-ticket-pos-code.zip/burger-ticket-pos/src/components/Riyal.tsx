/** Saudi Riyal currency symbol (new official sign) drawn as SVG so it renders on every device. */
export function RiyalSymbol({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 1124 1257"
      className={`inline-block h-[0.85em] w-auto align-[-0.05em] ${className}`}
      fill="currentColor"
      aria-label="SAR"
      role="img"
    >
      <path d="M699.6 1113.4c-20.8 46.2-34.6 96.3-39.8 148.8l422.9-89.9c20.8-46.2 34.6-96.3 39.8-148.8l-422.9 89.9z" />
      <path d="M1082.7 902.7c20.8-46.2 34.6-96.3 39.8-148.8l-329.4 70.1V689.3l290.8-61.8c20.8-46.2 34.6-96.3 39.8-148.8l-330.6 70.3V64.4c-50.6 28.4-95.6 66.3-132.2 110.9v402.9l-132.2 28.1V0c-50.6 28.4-95.6 66.3-132.2 110.9v473.2l-295.9 62.9c-20.8 46.2-34.7 96.3-39.9 148.8l335.8-71.4v169.6L46 978.5c-20.8 46.2-34.6 96.3-39.8 148.8l378.1-80.4c30.8-6.3 57.2-24.5 74.4-49.6l69.3-102.8v.03c7.2-10.6 11.4-23.5 11.4-37.3V684.2l132.2-28.1v270.4l410.1-87.2.03-.04z" />
    </svg>
  );
}

export function Money({ value, className = "" }: { value: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 whitespace-nowrap ${className}`}>
      <RiyalSymbol />
      {value.toFixed(2)}
    </span>
  );
}
