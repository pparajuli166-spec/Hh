import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import {
  Printer, ChefHat, Ban, BadgePercent, StickyNote, Tag, Settings, Search,
  Home, Clock, LayoutGrid, Plus, Minus, ArrowLeft, Trash2,
} from "lucide-react";
import { categories, type Product } from "@/lib/menu";
import { computeTotals, useSettings } from "@/lib/pos-settings";
import { printNetwork, type ReceiptData } from "@/lib/printer";
import { Money } from "@/components/Riyal";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Invoice } from "@/components/Invoice";
import { PaymentDialog } from "@/components/PaymentDialog";
import { printInvoiceNetwork, waitForInvoice } from "@/lib/receipt-print";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Burger Ticket POS — Cashier" },
      { name: "description", content: "Restaurant point of sale with network receipt printing." },
      { property: "og:title", content: "Burger Ticket POS — Cashier" },
      { property: "og:description", content: "Restaurant point of sale with network receipt printing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Pos,
});

interface Line { product: Product; qty: number }

function Pos() {
  const [settings] = useSettings();
  const [lines, setLines] = useState<Line[]>([]);
  const [catId, setCatId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [discount, setDiscount] = useState(0);
  const [checkNo, setCheckNo] = useState(() => 273268);
  const [orderType, setOrderType] = useState("DINE IN");
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [invoiceOpen, setInvoiceOpen] = useState(false);
  const [printing, setPrinting] = useState(false);

  const subtotal = lines.reduce((s, l) => s + l.qty * l.product.price, 0);
  const totals = computeTotals(subtotal, discount, settings.taxRate);

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return categories.flatMap((c) => c.products).filter((p) => p.name.toLowerCase().includes(q));
  }, [query]);
  const cat = categories.find((c) => c.id === catId);

  const add = (product: Product) =>
    setLines((ls) => {
      const f = ls.find((l) => l.product.id === product.id);
      return f ? ls.map((l) => (l === f ? { ...l, qty: l.qty + 1 } : l)) : [...ls, { product, qty: 1 }];
    });
  const change = (id: string, d: number) =>
    setLines((ls) => ls.map((l) => (l.product.id === id ? { ...l, qty: l.qty + d } : l)).filter((l) => l.qty > 0));

  const buildReceipt = (): ReceiptData => ({
    checkNo, orderType, date: new Date(),
    lines: lines.map((l) => ({ qty: l.qty, name: l.product.name, nameAr: l.product.nameAr, price: l.product.price })),
    ...totals,
  });

  const doPrint = async (kitchen = false) => {
    if (!kitchen && receipt && !lines.length) { setInvoiceOpen(true); return; }
    if (!lines.length) { toast.error("Add items first"); return; }
    const r = buildReceipt();
    if (!kitchen) { setReceipt(r); setInvoiceOpen(true); return; }
    if (settings.printMethod === "network") {
      const ip = kitchen ? settings.kitchenPrinterIp || settings.printerIp : settings.printerIp;
      try {
        await printNetwork(settings, r, ip, kitchen);
        toast.success(`Sent to printer ${ip}`);
      } catch {
        toast.error(`Printer ${ip} not reachable — check Settings`);
      }
      if (!kitchen && settings.printKitchenTicket && settings.kitchenPrinterIp) {
        printNetwork(settings, r, settings.kitchenPrinterIp, true).catch(() => toast.error("Kitchen printer not reachable"));
      }
    } else {
      setReceipt(r);
      setTimeout(() => window.print(), 100);
    }
  };

  const printInvoice = async () => {
    const element = document.getElementById("invoice-preview");
    if (!element || !receipt) return;
    setPrinting(true);
    try {
      if (settings.printMethod === "network") {
        await printInvoiceNetwork(element, settings);
        toast.success("Printer confirmed invoice printing");
      } else {
        const printElement = document.getElementById("receipt-print");
        if (!printElement) throw new Error("Invoice not ready");
        // The visible preview loads the same logo; the print copy is hidden until print media.
        await waitForInvoice(element);
        window.print();
      }
    } catch (e) { toast.error(e instanceof Error ? e.message : "Could not print invoice"); }
    finally { setPrinting(false); }
  };

  const completePayment = (payment: NonNullable<ReceiptData["payment"]>) => {
    const paid = { ...buildReceipt(), payment };
    setReceipt(paid); setPaymentOpen(false); setInvoiceOpen(true);
    setLines([]); setDiscount(0); setCheckNo(n => n + 1); setCatId(null); setQuery("");
    toast.success(`${payment.method} payment recorded`);
    if (settings.printKitchenTicket && settings.kitchenPrinterIp) printNetwork(settings, paid, settings.kitchenPrinterIp, true).catch(() => toast.error("Kitchen printer not reachable"));
  };

  const voidOrder = () => { setLines([]); setDiscount(0); toast("Order voided"); };
  const newOrder = async () => {
    if (lines.length && settings.autoPrint) await doPrint();
    setLines([]); setDiscount(0); setCheckNo((n) => n + 1); setCatId(null);
  };

  const actions = [
    { label: "Print", icon: Printer, onClick: () => doPrint() },
    { label: "Kitchen", icon: ChefHat, onClick: () => doPrint(true) },
    { label: "Void", icon: Ban, onClick: voidOrder },
    { label: "Discount", icon: BadgePercent, onClick: () => { const v = prompt("Discount amount", String(discount)); if (v !== null) setDiscount(Math.max(0, Number(v) || 0)); } },
    { label: "Notes", icon: StickyNote, onClick: () => prompt("Order note") },
    { label: "Tags", icon: Tag, onClick: () => setOrderType((t) => (t === "DINE IN" ? "TAKE AWAY" : "DINE IN")) },
  ];

  return (
    <div className="min-h-screen p-3 md:p-5">
      <div className="mx-auto flex max-w-[1400px] flex-col gap-4 lg:flex-row">
        {/* Order panel */}
        <aside className="flex flex-col overflow-hidden rounded-md bg-card shadow-sm lg:sticky lg:top-5 lg:h-[calc(100vh-2.5rem)] lg:w-[380px] lg:shrink-0">
          <div className="border-b px-6 py-4 font-semibold">
            <div className="flex justify-between"><span className="text-primary">{checkNo}</span><span>ACTIVE</span></div>
            <div className="mt-3 flex justify-between text-primary">
              <button onClick={() => setOrderType((t) => (t === "DINE IN" ? "TAKE AWAY" : "DINE IN"))}>{orderType} ({lines.reduce((s, l) => s + l.qty, 0)})</button>
              <button onClick={() => prompt("Customer name")}>ADD CUSTOMER</button>
            </div>
          </div>
          <div className="min-h-[160px] flex-1 overflow-y-auto px-5">
            {lines.length === 0 && <p className="py-10 text-center text-muted-foreground">No items yet</p>}
            {lines.map((l) => (
              <div key={l.product.id} className="flex items-center gap-3 border-b border-dashed py-4">
                <div className="flex flex-col items-center gap-1">
                  <button aria-label="Increase" onClick={() => change(l.product.id, 1)} className="rounded bg-accent p-1 text-accent-foreground"><Plus className="h-3 w-3" /></button>
                  <span className="text-sm">{l.qty}x</span>
                  <button aria-label="Decrease" onClick={() => change(l.product.id, -1)} className="rounded bg-accent p-1 text-accent-foreground">{l.qty === 1 ? <Trash2 className="h-3 w-3" /> : <Minus className="h-3 w-3" />}</button>
                </div>
                <span className="flex-1 text-lg">{l.product.name}</span>
                <Money value={l.qty * l.product.price} className="text-lg text-muted-foreground" />
              </div>
            ))}
          </div>
          <div className="space-y-2 bg-muted/50 px-5 py-4 text-muted-foreground">
            <Row label="Subtotal" v={totals.subtotal} />
            <Row label="Discount" v={totals.discount} />
            <Row label={`Taxes (${settings.taxRate}%)`} v={totals.taxes} />
          </div>
          <Button disabled={!lines.length} onClick={() => setPaymentOpen(true)} className="flex h-auto justify-between rounded-none px-6 py-4 text-2xl font-bold">
            <span>PAY</span><Money value={totals.total} />
          </Button>
        </aside>

        {/* Main */}
        <main className="flex flex-1 flex-col gap-4">
          <div className="grid grid-cols-4 gap-3 sm:grid-cols-7">
            {actions.map((a) => (
              <button key={a.label} onClick={a.onClick} className="flex aspect-square flex-col items-center justify-center gap-2 rounded-md bg-primary text-primary-foreground shadow-sm transition active:scale-95 sm:aspect-auto sm:h-24">
                <a.icon className="h-8 w-8" strokeWidth={1.5} />
                <span className="text-[11px] font-semibold uppercase">{a.label}</span>
              </button>
            ))}
            <Link to="/settings" className="flex aspect-square flex-col items-center justify-center gap-2 rounded-md bg-primary text-primary-foreground shadow-sm sm:aspect-auto sm:h-24">
              <Settings className="h-8 w-8" strokeWidth={1.5} />
              <span className="text-[11px] font-semibold uppercase">Settings</span>
            </Link>
          </div>

          <label className="flex items-center rounded-md bg-card px-5 py-4 shadow-sm">
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search products" className="flex-1 bg-transparent text-xl outline-none placeholder:text-muted-foreground" />
            <Search className="h-6 w-6 text-primary" />
          </label>

          {cat && !searchResults && (
            <button onClick={() => setCatId(null)} className="flex w-fit items-center gap-2 rounded-md bg-primary px-5 py-3 font-semibold text-primary-foreground">
              <ArrowLeft className="h-4 w-4" /> BACK
            </button>
          )}

          <div className="grid flex-1 grid-cols-2 content-start gap-4 sm:grid-cols-3 xl:grid-cols-5">
            {searchResults
              ? searchResults.map((p) => <ProductTile key={p.id} p={p} onClick={() => add(p)} />)
              : cat
                ? cat.products.map((p) => <ProductTile key={p.id} p={p} onClick={() => add(p)} />)
                : categories.map((c) => (
                    <button key={c.id} onClick={() => setCatId(c.id)} className="overflow-hidden rounded-sm border-b-4 border-primary bg-card text-left shadow-sm transition active:scale-95">
                      <img src={c.image} alt={c.name} loading="lazy" width={816} height={816} className="aspect-[4/3] w-full object-cover" />
                      <div className="py-4 text-center font-bold uppercase">{c.name}</div>
                    </button>
                  ))}
          </div>

          <nav className="grid grid-cols-4 rounded-md bg-card py-4 font-semibold shadow-sm">
            <NavItem icon={Home} label="Home" onClick={() => { setCatId(null); setQuery(""); }} />
            <NavItem icon={Clock} label="Orders" onClick={() => toast("Orders history coming soon")} />
            <NavItem icon={LayoutGrid} label="Tables" onClick={() => toast("Tables coming soon")} />
            <NavItem icon={Plus} label="New" onClick={newOrder} />
          </nav>
        </main>
      </div>

      {paymentOpen && <PaymentDialog total={totals.total} onClose={() => setPaymentOpen(false)} onComplete={completePayment} />}
      <Dialog open={invoiceOpen} onOpenChange={setInvoiceOpen}><DialogContent className="max-h-[92dvh] max-w-[calc(100vw-1rem)] overflow-y-auto bg-card sm:max-w-md"><DialogTitle>Invoice {receipt?.payment ? "· Paid" : "· Preview"}</DialogTitle><DialogDescription>Order #{receipt?.checkNo}</DialogDescription>{receipt && <Invoice id="invoice-preview" r={receipt} settings={settings} />}{!settings.vatNumber && <p className="text-sm text-destructive">Set your actual seller name and 15-digit VAT number in Settings for the tax QR.</p>}<Button disabled={printing} onClick={printInvoice}><Printer />{printing ? "Printing…" : "Print / Save PDF"}</Button></DialogContent></Dialog>
      {receipt && createPortal(<Invoice id="receipt-print" r={receipt} settings={settings} />, document.body)}
    </div>
  );

}

function Row({ label, v }: { label: string; v: number }) {
  return <div className="flex justify-between"><span>{label}</span><Money value={v} /></div>;
}

function ProductTile({ p, onClick }: { p: Product; onClick: () => void }) {
  return (
    <button onClick={onClick} className="overflow-hidden rounded-sm border-b-4 border-primary bg-card shadow-sm transition active:scale-95">
      <img src={p.image} alt={p.name} loading="lazy" width={816} height={816} className="aspect-[4/3] w-full object-cover" />
      <div className="px-2 pt-3 text-center font-bold">{p.name}</div>
      <div lang="ar" dir="rtl" className="px-2 py-1 text-center text-sm text-muted-foreground">{p.nameAr}</div>
      <div className="pb-3 text-center text-primary"><Money value={p.price} /></div>
    </button>
  );
}

function NavItem({ icon: Icon, label, onClick }: { icon: typeof Home; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex items-center justify-center gap-2 uppercase">
      <Icon className="h-6 w-6 text-primary" /> <span className="hidden sm:inline">{label}</span>
    </button>
  );
}
