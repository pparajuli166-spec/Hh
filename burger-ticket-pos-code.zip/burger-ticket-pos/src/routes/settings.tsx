import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ArrowLeft, Wifi, Printer as PrinterIcon, Save } from "lucide-react";
import { defaultSettings, saveSettings, useSettings, type PosSettings } from "@/lib/pos-settings";
import { pingPrinter, printNetwork } from "@/lib/printer";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Burger Ticket POS" },
      { name: "description", content: "Store, tax and network printer settings for the POS." },
      { property: "og:title", content: "Settings — Burger Ticket POS" },
      { property: "og:description", content: "Store, tax and network printer settings for the POS." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const [s, setS] = useSettings();
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof PosSettings>(k: K, v: PosSettings[K]) => setS({ ...s, [k]: v });

  const save = () => { saveSettings(s); toast.success("Settings saved"); };

  const ping = async (ip: string) => {
    if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) { toast.error("Enter a valid IP like 192.168.1.100"); return; }
    setBusy(true); setStatus(`Pinging ${ip}...`);
    const r = await pingPrinter(s, ip);
    setBusy(false);
    setStatus(r.ok ? `✅ ${ip} replied in ${r.ms} ms — connected` : `❌ ${ip}: ${r.error}`);
  };

  const testPrint = async () => {
    saveSettings(s);
    try {
      await printNetwork({ ...s, copies: 1 }, {
        checkNo: 0, orderType: "TEST", date: new Date(),
        lines: [{ qty: 1, name: "Test print OK", price: 0 }],
        subtotal: 0, discount: 0, taxes: 0, total: 0,
      });
      toast.success("Test page sent");
    } catch { toast.error("Could not reach printer"); }
  };

  const isHttpsPage = typeof window !== "undefined" && window.location.protocol === "https:";

  return (
    <div className="min-h-screen p-3 md:p-5">
      <div className="mx-auto max-w-4xl space-y-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 rounded-md bg-primary px-5 py-3 font-semibold text-primary-foreground"><ArrowLeft className="h-4 w-4" /> BACK</Link>
          <button onClick={save} className="flex items-center gap-2 rounded-md bg-primary px-5 py-3 font-semibold text-primary-foreground"><Save className="h-4 w-4" /> SAVE</button>
        </div>

        <Section title="Printer">
          <Field label="Print method">
            <select className={input} value={s.printMethod} onChange={(e) => set("printMethod", e.target.value as PosSettings["printMethod"])}>
              <option value="browser">Device printer (paired / AirPrint / Bluetooth)</option>
              <option value="network">Network printer by IP (Epson ePOS)</option>
            </select>
          </Field>
          <Field label="Printer IP address"><input className={input} value={s.printerIp} onChange={(e) => set("printerIp", e.target.value.trim())} placeholder="192.168.1.100" inputMode="decimal" /></Field>
          <Field label="Port"><input className={input} type="number" value={s.printerPort} onChange={(e) => set("printerPort", Number(e.target.value))} /></Field>
          <Field label="Connection">
            <select className={input} value={s.printerProtocol} onChange={(e) => set("printerProtocol", e.target.value as "http" | "https")}>
              <option value="http">HTTP</option><option value="https">HTTPS</option>
            </select>
          </Field>
          <Field label="Paper width">
            <select className={input} value={s.paperWidth} onChange={(e) => set("paperWidth", Number(e.target.value) as 58 | 80)}>
              <option value={80}>80 mm</option><option value={58}>58 mm</option>
            </select>
          </Field>
          <Field label="Copies"><input className={input} type="number" min={1} max={5} value={s.copies} onChange={(e) => set("copies", Math.max(1, Number(e.target.value)))} /></Field>
          <div className="col-span-full flex flex-wrap gap-3">
            <button disabled={busy} onClick={() => ping(s.printerIp)} className={btn}><Wifi className="h-4 w-4" /> PING PRINTER</button>
            <button onClick={testPrint} className={btn}><PrinterIcon className="h-4 w-4" /> TEST PRINT</button>
          </div>
          {status && <p className="col-span-full rounded-md bg-muted p-3 font-semibold">{status}</p>}
          {isHttpsPage && s.printMethod === "network" && s.printerProtocol === "http" && (
            <p className="col-span-full rounded-md bg-accent p-3 text-sm text-accent-foreground">
              Note: this page is opened on a secure (https) link, so the browser may block plain HTTP to the printer. Turn on HTTPS / SSL in the printer's web settings and choose HTTPS above, or open the printer's address once in this browser and accept its certificate.
            </p>
          )}
          <Toggle label="Auto-print unpaid receipt on NEW order" v={s.autoPrint} on={(v) => set("autoPrint", v)} />
          <Toggle label="Cut paper after print" v={s.cutPaper} on={(v) => set("cutPaper", v)} />
          <Toggle label="Open cash drawer" v={s.openCashDrawer} on={(v) => set("openCashDrawer", v)} />
        </Section>

        <Section title="Kitchen printer">
          <Toggle label="Also print kitchen ticket with receipt" v={s.printKitchenTicket} on={(v) => set("printKitchenTicket", v)} />
          <Field label="Kitchen printer IP"><input className={input} value={s.kitchenPrinterIp} onChange={(e) => set("kitchenPrinterIp", e.target.value.trim())} placeholder="192.168.1.101" /></Field>
          <div className="flex items-end"><button disabled={busy} onClick={() => ping(s.kitchenPrinterIp)} className={btn}><Wifi className="h-4 w-4" /> PING KITCHEN</button></div>
        </Section>

        <Section title="Store & receipt">
          <Field label="Store name"><input className={input} value={s.storeName} onChange={(e) => set("storeName", e.target.value)} /></Field>
          <Field label="Branch"><input className={input} value={s.branchName} onChange={(e) => set("branchName", e.target.value)} /></Field>
          <Field label="VAT number"><input className={input} value={s.vatNumber} onChange={(e) => set("vatNumber", e.target.value)} /></Field>
          <Field label="Phone"><input className={input} value={s.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label="Address"><input className={input} value={s.address} onChange={(e) => set("address", e.target.value)} /></Field>
          <Field label="Cashier name"><input className={input} value={s.cashierName} onChange={(e) => set("cashierName", e.target.value)} /></Field>
          <Field label="VAT % (included in price)"><input className={input} type="number" value={s.taxRate} onChange={(e) => set("taxRate", Number(e.target.value))} /></Field>
          <Field label="Receipt footer"><input className={input} value={s.receiptFooter} onChange={(e) => set("receiptFooter", e.target.value)} /></Field>
        </Section>

        <button onClick={() => { setS(defaultSettings); saveSettings(defaultSettings); toast("Reset to defaults"); }} className="text-sm text-destructive underline">Reset all settings</button>
      </div>
    </div>
  );
}

const input = "w-full rounded-md border bg-background px-3 py-2.5 outline-none focus:ring-2 focus:ring-ring";
const btn = "flex items-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground disabled:opacity-50";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-md bg-card p-5 shadow-sm">
      <h2 className="mb-4 text-lg font-bold uppercase text-primary">{title}</h2>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </section>
  );
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="mb-1 block text-sm font-semibold text-muted-foreground uppercase">{label}</span>{children}</label>;
}
function Toggle({ label, v, on }: { label: string; v: boolean; on: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between rounded-md border px-3 py-2.5">
      <span>{label}</span>
      <input type="checkbox" checked={v} onChange={(e) => on(e.target.checked)} className="h-5 w-5 accent-primary" />
    </label>
  );
}
